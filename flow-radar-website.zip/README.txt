FLOW RADAR｜加密貨幣大額成交異動監控網站

使用方式
1. 打開 index.html，即可開始連線各交易所公開的 WebSocket 成交資料。
2. 推薦把 index.html 上傳到 GitHub Pages，透過 HTTPS 網址開啟（手機也能看）。
3. 設定可以調整單筆大額成交、近 60 秒成交量及量能倍數，並新增幣種。
4. 交易所狀態會顯示是否連線，只有成功收到的幣種才會出現即時價格。
5. 量能暴增需要至少 3 個完整的歷史分鐘作為比較基準，通常須等待約 3～4 分鐘。

支援來源（公開現貨交易）
Binance：USDT 現貨 aggregate trade
Bybit：USDT 現貨 publicTrade
OKX：USDT 現貨 trades
Coinbase：USD 現貨 market_trades
Kraken：USD 現貨 trade

注意
- 不必輸入 API Key，不讀取交易帳戶，不會交易或下單。
- 交易所是否提供某幣交易對依實際上架情況而定；無上架或遭地區封鎖時不會有資料。
- 網頁關閉就停止資料收集，紀錄和設定保留在目前瀏覽器 localStorage。
- USD 與 USDT 成交額以美元約當彙總，並非即時匯率精算。
- Coinbase market_trades 的 maker side 已轉為 taker side；其他來源直接取吃單方向。
- 大額交易不是單一錢包識別、也不是預測上漲或下跌的可靠保證。
- 靜態網站無法保證手機鎖螢幕後持續執行；如需 24 小時警報和 Telegram 推播，需要雲端後端持續連線。

GitHub Pages 部署步驟
1. 新建一個 GitHub repository，例如 crypto-flow-radar。
2. 在 repository 根目錄上傳 index.html（名稱必須為 index.html）。
3. 開啟 Settings > Pages，Source 選 Deploy from a branch；Branch 選 main、/(root)，儲存。
4. 等候部署完成，打開 GitHub Pages 產生的 HTTPS 網址。

FAQ
Q: 為什麼只有部分幣種有數字？
A: 各交易所上市的幣種不同，且網路區域限制也可能造成缺資料。
Q: 為什麼還沒有 3x 量能警報？
A: 需要先取得至少三個完整分鐘的歷史成交樣本，設定門檻也可能還沒達到。
Q: 網頁關閉後會通知我嗎？
A: 不會。要 24 小時不中斷與手機 Telegram 推播，需加雲端主機與持久資料庫。
